namespace UnitAdminPackage.Models
{
    public class ClothingCard
    {
        public int Id { get; set; }
        public string IndividualName { get; set; }
        public string ItemIssued { get; set; }
        public DateTime DateOfIssue { get; set; }
        public string Quantity { get; set; }
        public string IssuedBy { get; set; }
    }
}
