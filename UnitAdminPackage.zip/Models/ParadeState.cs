namespace UnitAdminPackage.Models
{
    public class ParadeState
    {
        public int Id { get; set; }
        public string IndividualName { get; set; }
        public string Unit { get; set; }
        public DateTime Date { get; set; }
        public bool IsPresent { get; set; }
        public string Remarks { get; set; }
    }
}
