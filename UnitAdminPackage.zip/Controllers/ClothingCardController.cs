using Microsoft.AspNetCore.Mvc;
using UnitAdminPackage.Data;
using UnitAdminPackage.Models;
using Microsoft.EntityFrameworkCore;

public class ClothingCardController : Controller
{
    private readonly ApplicationDbContext _context;

    public ClothingCardController(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index() => View(await _context.ClothingCards.ToListAsync());

    public IActionResult Create() => View();

    [HttpPost]
    public async Task<IActionResult> Create(ClothingCard model)
    {
        if (ModelState.IsValid)
        {
            _context.ClothingCards.Add(model);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(model);
    }

    public async Task<IActionResult> Edit(int id)
    {
        var data = await _context.ClothingCards.FindAsync(id);
        return View(data);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(ClothingCard model)
    {
        if (ModelState.IsValid)
        {
            _context.ClothingCards.Update(model);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(model);
    }

    public async Task<IActionResult> Delete(int id)
    {
        var data = await _context.ClothingCards.FindAsync(id);
        _context.ClothingCards.Remove(data);
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }
}
