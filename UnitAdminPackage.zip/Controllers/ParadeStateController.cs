using Microsoft.AspNetCore.Mvc;
using UnitAdminPackage.Data;
using UnitAdminPackage.Models;
using Microsoft.EntityFrameworkCore;

public class ParadeStateController : Controller
{
    private readonly ApplicationDbContext _context;

    public ParadeStateController(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index() => View(await _context.ParadeStates.ToListAsync());

    public IActionResult Create() => View();

    [HttpPost]
    public async Task<IActionResult> Create(ParadeState model)
    {
        if (ModelState.IsValid)
        {
            _context.ParadeStates.Add(model);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(model);
    }

    public async Task<IActionResult> Edit(int id)
    {
        var data = await _context.ParadeStates.FindAsync(id);
        return View(data);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(ParadeState model)
    {
        if (ModelState.IsValid)
        {
            _context.ParadeStates.Update(model);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(model);
    }

    public async Task<IActionResult> Delete(int id)
    {
        var data = await _context.ParadeStates.FindAsync(id);
        _context.ParadeStates.Remove(data);
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }
}
