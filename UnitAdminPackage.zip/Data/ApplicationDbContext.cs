using Microsoft.EntityFrameworkCore;
using UnitAdminPackage.Models;

namespace UnitAdminPackage.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<ParadeState> ParadeStates { get; set; }
        public DbSet<ClothingCard> ClothingCards { get; set; }
    }
}
